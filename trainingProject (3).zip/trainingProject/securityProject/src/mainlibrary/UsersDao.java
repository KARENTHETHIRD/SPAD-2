/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainlibrary;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author bikash
 */
public class UsersDao {

    public static boolean validate(String name, String password) {
        boolean status = false;
        try {
            Connection con = DB.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from Users where UserName = ? and UserPass = ? ");
            ps.setString(1, name);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();				//.........Issues.......1.........
            status = rs.next();								//.........Changes......1.........
            con.close();
            ps.close();
            rs.close();
        } catch (Exception e) {
        	e.printStackTrace();
        }
        return status;
    }

    public static boolean CheckIfAlready(String string) {
        boolean status = false;
        try {
            Connection con = DB.getConnection();
            String select = "select * from Users where Email = '" + string +"'";
            Statement selectStatement = con.createStatement();
            ResultSet rs = selectStatement.executeQuery(select);
            status = rs.next();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return status;

    }

    public static int AddUser(String User, String UserPass, String UserEmail, String Date) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

        int status = 0;
        Connection con = null;
        PreparedStatement ps = null;
        try {

            con = DB.getConnection();
            con.setAutoCommit(false);
            ps = con.prepareStatement("insert into Users(UserPass,RegDate,UserName,Email) values(?,?,?,?)");
            ps.setString(1, UserPass);
            ps.setString(2, Date);
            ps.setString(3, User);
            ps.setString(4, UserEmail);
            status = ps.executeUpdate();
            if(status > 0)								
            	con.commit();
            else										//........Issues......2.........
            	con.rollback();							//Failed to close connection if error is thrown(ie, no close inside catch)
        } catch (Exception e) {							//Failed to close statement.
        	try{										//The connection is committed without considering the output(ie, the connection
            	con.rollback();							//is committed even if there is no desired output). 
        	}catch(SQLException se){					//Failed to print stack trace(so it is difficult to debug).
        		se.printStackTrace();
        	}											//.......Changes.......2........
        	e.printStackTrace();						//Connection is closed inside the finally clause(ie, connection is closed even if error is thrown).
        }finally{										//Statement is closed inside finally clause.
        	try{										//The connection is committed only if we got the the desired o/p
        		ps.close();								//else all changes will be roll backed.
        		con.close();							//Stack Trace printed.
        	}catch(SQLException sqe){
        		sqe.printStackTrace();
        	}
        }
        return status;

    }

}

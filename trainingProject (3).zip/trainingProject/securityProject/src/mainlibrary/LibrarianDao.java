package mainlibrary;

import java.sql.*;

import javax.swing.JOptionPane;

public class LibrarianDao {

    public static int save(String name, String password, String email, String address, String city, String contact) {
        int status = 0;
        try {

            Connection con = DB.getConnection();
            con.setAutoCommit(false);
            PreparedStatement ps = con.prepareStatement("insert into librarian(name,password,email,address,city,contact) values(?,?,?,?,?,?)");
            ps.setString(1, name);
            ps.setString(2, password);
            ps.setString(3, email);
            ps.setString(4, address);
            ps.setString(5, city);
            ps.setString(6, contact);
            status = ps.executeUpdate();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return status;
    }

    public static int delete(int id) {
        int status = 0;
        try {
            Connection con = DB.getConnection();
            PreparedStatement ps = con.prepareStatement("delete from Librarian where id=?");
            ps.setInt(1, id);
            status = ps.executeUpdate();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return status;
    }

    public static boolean validate(String name, String password) {
        boolean status = false;
        try {
            Connection con = DB.getConnection();
//            String select = "select * from Librarian where UserName= '" + name + "' and Password='"+ password +"'";
//            Statement selectStatement = con.createStatement();
//            ResultSet rs = selectStatement.executeQuery(select);
            
            PreparedStatement ps = con.prepareStatement("select * from Librarian where UserName = ? and Password = ?");
            ps.setString(1, name);										
            ps.setString(2, password);									
            ResultSet rs = ps.executeQuery();							//.........Issues.......1.........
            status = rs.next();											//In the previous code UserName and Password are directly appended with select string
            con.close();												//it can be easily modified by SQL Injection and it may cause fraud login.
            ps.close();													//bcz here we check only for the query return a result set or not, no further check.
            rs.close();													//the hackers can easily login by modifying the query as "select * from Librarian"
        } catch (Exception e) {											//bcz execution of this query return a non empty resultSet and it will make the 
            e.printStackTrace();										//boolean "status" as true.
        }																//Failed to close result set and statement, Failed to print stack trace.
        return status;													
        																//.........Changes......1.........
    }																	//Used preparedStatement to prepare a safe query.
    																	//Result set and statement closed.
}																		//Stack trace is printed.
																		